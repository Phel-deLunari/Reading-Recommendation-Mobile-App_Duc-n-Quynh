import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(home: Man_hinh_chinh()));
}

void hien_thi_man_hinh(BuildContext context, Widget man_hinh) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) {
        return man_hinh;
      },
    ),
  );
}

void quay_ve_man_hinh_truoc(BuildContext context) {
  Navigator.pop(context);
}

void quay_ve_man_hinh_chinh(BuildContext context) {
  Navigator.popUntil(context, (Route route) {
    return route.isFirst;
  });
}

class Man_hinh_chinh extends StatelessWidget {
  const Man_hinh_chinh({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.grey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Thư viện sách',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              hien_thi_man_hinh(context, Thu_vien_cua_toi());
            },
            child: Text('Thư viện sách'),
          ),
          ElevatedButton(
            onPressed: () {
              hien_thi_man_hinh(context, Cai_dat());
            },
            child: Text('Cài đặt'),
          ),
          ElevatedButton(
            onPressed: () {
              hien_thi_man_hinh(context, Thong_tin_nguoi_dung());
            },
            child: Text('Thông tin người dùng'),
          ),
        ],
      ),
    );
  }
}

class Thu_vien_cua_toi extends StatelessWidget {
  const Thu_vien_cua_toi({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Thư viện của tôi',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 15),
            Text('Danh sách sách bạn đã lưu hoặc muốn đọc.'),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                quay_ve_man_hinh_truoc(context);
              },
              child: Text('Quay lại'),
            ),
          ],
        ),
      ),
    );
  }
}

class Cai_dat extends StatelessWidget {
  const Cai_dat({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Cài đặt',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 15),
          Text('Tùy chỉnh ngôn ngữ, giao diện hoặc chế độ tối.'),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              quay_ve_man_hinh_truoc(context);
            },
            child: Text('Quay lại'),
          ),
        ],
      ),
    );
  }
}

class Thong_tin_nguoi_dung extends StatelessWidget {
  const Thong_tin_nguoi_dung({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              '👤 Thông tin cá nhân',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text('Tên: Vũ Mai Quỳnh'),
            Text('Email: 23010223@st.phenikaa-uni.edu.vn'),
            Text('Sở thích: Đọc sách, nghe nhạc, chơi game'),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                quay_ve_man_hinh_truoc(context);
              },
              child: Text('⬅️ Quay lại'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                quay_ve_man_hinh_chinh(context);
              },
              child: Text('Về màn hình chính'),
            ),
          ],
        ),
      ),
    );
  }
}
